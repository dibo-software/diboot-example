export const printANSI = () => {
  console.log('感谢使用 Diboot Antd Admin!')
  console.log('Thanks for using diboot antd admin!')
}
