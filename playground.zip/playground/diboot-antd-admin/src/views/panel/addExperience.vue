<template>
  <a-card :bordered="false">

  </a-card>
</template>

<script>
import form from '@/components/diboot/mixins/form'
import { dibootApi } from '@/utils/request'

export default {
  name: 'addExperience',
  mixins: [form],
  data () {
    return {
			baseApi: '/workExperience',
      form: this.$form.createForm(this),
      attachMoreList: [
        {
          type: 'T',
          target: 'employee',
          key: 'realname',
          value: 'id'
        },
        {
          type: 'D',
          target: 'POSITION_GRADE'
        }
      ]
    }
  },
  methods: {
    
    open () {
  this.attachMore()
},
    async submit () {
  this.state.confirmSubmit = true
  const values = await this.validate()
  this.enhance(values)
  try {
    const res = await dibootApi.post(`${this.baseApi}/`, values)
    if (res.code === 0) {
      this.submitSuccess(res)
    } else {
      this.submitFailed(res)
    }
  } catch (e) {
    // 执行一系列后续操作
    this.submitFailed(e)
  }
},
    submitSuccess (result) {
  this.$notification.success({
    message: '操作成功',
    description: result.msg
  })
  this.close()
  this.form.resetFields()
  this.$emit('complete')
}
  },
  watch: {
    
    employeeId: function(val) {
  // 数据更改处理流程
}
  },
  props: {
    
    employeeId: {
      type: String
    }
  }

}
</script>
<style lang="less" scoped>
</style>