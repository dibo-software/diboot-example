<template>
  <a-drawer
    class="detail-wrapper"
    :title="title"
    :width="720"
    @close="close"
    :visible="visible"
    :body-style="{ paddingBottom: '80px' }"
  >
    <a-descriptions :column="2">
      <a-descriptions-item label="姓名">
        {{ model.realname }}
      </a-descriptions-item>
      <a-descriptions-item label="身份证号">
        {{ model.idcard }}
      </a-descriptions-item>
      <a-descriptions-item label="生日">
        {{ model.birthdate }}
      </a-descriptions-item>
      <a-descriptions-item label="电话">
        {{ model.cellphone }}
      </a-descriptions-item>
      <a-descriptions-item label="邮箱">
        {{ model.email }}
      </a-descriptions-item>
      <a-descriptions-item label="创建时间">
        {{ model.createTime }}
      </a-descriptions-item>
      <a-descriptions-item label="部门">
        {{ model.iamOrgShortName }}
      </a-descriptions-item>
    </a-descriptions>
<h3 style="padding: 0 0px; min-height: 50px; line-height: 50px; font-weight: 500; font-size: 20px; text-align: left;border-bottom: 1px solid ;color: #68BC00;">
	工作经历列表
</h3>
    <a-table
      ref="table"
      size="default"
      :columns="columns"
      :dataSource="model.workExperienceList"
      :pagination="false"
      rowKey="id"
    >
    </a-table>
    <div class="drawer-footer">
      <a-button :style="{marginRight: '8px'}" @click="close">关闭</a-button>
    </div>
  </a-drawer>
</template>

<script>
import detail from '@/components/diboot/mixins/detail'

export default {
  name: 'EmployeeDetail',
  mixins: [detail],
  data () {
    return {
      baseApi: '/employee',
			columns: [
      {
        title: '单位',
        dataIndex: 'corpName'
      },
      {
        title: '电话',
        dataIndex: 'corpPhone'
      },
      {
        title: '起始日期',
        dataIndex: 'beginDate'
      },
      {
        title: '截止日期',
        dataIndex: 'endDate'
      },
      {
        title: '联系人',
        dataIndex: 'contactPerson'
      },
      {
        title: '联系人邮箱',
        dataIndex: 'contactEmail'
      },
      {
        title: '创建时间',
        dataIndex: 'createTime'
      },
  		]
    }
  },
  methods: {
    onAfterOpen() {
  // 事件处理代码
},
    afterOpen () {
			this.onAfterOpen()
    }
  }
}
</script>
<style lang="less" scoped>
</style>
