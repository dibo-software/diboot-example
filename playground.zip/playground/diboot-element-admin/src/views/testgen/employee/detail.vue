<template>
  <el-dialog
    :visible.sync="visible"
    :fullscreen="fullscreen"
    :custom-class="!fullscreen ? 'custom-height': 'custom-fullscreen'"
    :show-close="false"
  >
    <el-row slot="title" type="flex">
      <el-col :span="20">{{title}}</el-col>
      <el-col :span="4" style="text-align: right">
        <svg-icon
          :icon-class="!fullscreen ? 'fullscreen': 'exit-fullscreen'"
          style="cursor: pointer; margin-right: 10px"
          @click="() => {fullscreen = !fullscreen}"
        />
          <i class="el-icon-close" style="cursor: pointer" @click="close" />
      </el-col>
    </el-row>
    <el-form label-position="left" inline class="detail-item-container">
      <el-row :gutter="18">
    <el-col :span="12">
      <el-form-item label="姓名">
        <span>{{ model.realname }}</span>
      </el-form-item>
    </el-col>
    <el-col :span="12">
      <el-form-item label="身份证号">
        <span>{{ model.idcard }}</span>
      </el-form-item>
    </el-col>
    <el-col :span="12">
      <el-form-item label="生日">
        <span>{{ model.birthdate }}</span>
      </el-form-item>
    </el-col>
    <el-col :span="12">
      <el-form-item label="电话">
        <span>{{ model.cellphone }}</span>
      </el-form-item>
    </el-col>
    <el-col :span="12">
      <el-form-item label="邮箱">
        <span>{{ model.email }}</span>
      </el-form-item>
    </el-col>
    <el-col :span="12">
      <el-form-item label="创建时间">
        <span>{{ model.createTime }}</span>
      </el-form-item>
    </el-col>
    <el-col :span="12">
      <el-form-item label="部门">
        <span>{{ model.iamOrgShortName }}</span>
      </el-form-item>
    </el-col>
  </el-row>
</el-form>


    <div class="table-operator" style="text-align: left;">
      <el-button type="primary" icon="" @click="$refs.addExperienceWindow.open()">
        添加经历
      </el-button>
    </div>
		<modal-window :width="1200" title="" ref="addExperienceWindow">
    <add-experience ref="addExperience" slot="content" />
    </modal-window>

<h3 style="padding: 0 0px; min-height: 50px; line-height: 50px; font-weight: 500; font-size: 20px; text-align: left;border-bottom: 2px solid ;color: #68BC00;">
	工作经历
</h3>
    <el-table
    		ref="table"
        style="width: 100%"
        :data="model.workExperienceList"
      >
        <el-table-column
          v-for="(column, index) in columns"
          :key="`data-table-${_uid}-${index}`"
          :prop="column.dataIndex"
          :label="column.title">
        </el-table-column>
      </el-table>
    <div slot="footer" class="dialog-footer">
      <el-button @click="close">关闭</el-button>
    </div>
  </el-dialog>
</template>

<script>
import detail from '@/components/diboot/mixins/detail'
import addExperience from '@/views/panel/addExperience' 
import modalWindow from '@/components/diboot/components/popWindow/modalWindow'
export default {
  name: 'EmployeeDetail',
  components: {
        addExperience,
    modalWindow
  },
  mixins: [detail],
  data() {
    return {
      baseApi: '/employee',
      			columns: [
      {
        title: '单位',
        dataIndex: 'corpName'
      },
      {
        title: '电话',
        dataIndex: 'corpPhone'
      },
      {
        title: '起始日期',
        dataIndex: 'beginDate'
      },
      {
        title: '截止日期',
        dataIndex: 'endDate'
      },
      {
        title: '联系人',
        dataIndex: 'contactPerson'
      },
      {
        title: '联系人邮箱',
        dataIndex: 'contactEmail'
      },
      {
        title: '创建人',
        dataIndex: 'createBy'
      },
      {
        title: '创建时间',
        dataIndex: 'createTime'
      },
      {
        title: '更新时间',
        dataIndex: 'updateTime'
      },
  		]
    }
  }
}
</script>
<style lang="scss" scoped>
</style>
