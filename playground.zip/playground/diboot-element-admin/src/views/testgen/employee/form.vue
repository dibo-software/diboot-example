<template>
    <el-dialog
      :visible.sync="state.visible"
      :fullscreen="fullscreen"
      :custom-class="!fullscreen ? 'custom-height': 'custom-fullscreen'"
      :show-close="false"
    >
        <el-row slot="title" type="flex">
            <el-col :span="20">{{ title }}</el-col>
            <el-col :span="4" style="text-align: right">
                <svg-icon
                  :icon-class="!fullscreen ? 'fullscreen': 'exit-fullscreen'"
                  style="cursor: pointer; margin-right: 10px"
                  @click="() => {fullscreen = !fullscreen}"
                />
                <i class="el-icon-close" style="cursor: pointer" @click="close" />
            </el-col>
        </el-row>
        

<el-form ref="dataForm" :model="form" label-position="right" label-width="100px">
  <el-row :gutter="18">
      <el-col :span="12">
        <el-form-item
          label="部门"
        >
          <el-select
            filterable
            placeholder="请选择部门"
            v-model="form.orgId"
            style="width: 100%;"
          >
            <el-option
              value=""
              label="-- 请选择 --"
            />
            <el-option
              v-if="more.iamOrgKvList"
              v-for="(item, index) in more.iamOrgKvList"
              :key="index"
              :value="`${item.v}`"
              :label="item.k"
            >
            </el-option>
          </el-select>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item
          label="姓名"
          prop="realname"
          :rules="{
            required: true, message: '姓名不能为空', trigger: 'blur', whitespace: true
          }"
        >
          <el-input
            placeholder="请输入姓名"
            v-model="form.realname"
          />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item
          label="身份证号"
          prop="idcard"
          :rules="{
            required: true, message: '身份证号不能为空', trigger: 'blur', whitespace: true
          }"
        >
          <el-input
            placeholder="请输入身份证号"
            v-model="form.idcard"
          />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item
          label="生日"
        >
          <el-date-picker
            v-model="form.birthdate"
            type="date"
            style="width: 100%;"
          />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item
          label="电话"
        >
          <el-input
            placeholder="请输入电话"
            v-model="form.cellphone"
          />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item
          label="邮箱"
        >
          <el-input
            placeholder="请输入邮箱"
            v-model="form.email"
          />
        </el-form-item>
      </el-col>
  </el-row>
</el-form>
        <div slot="footer" class="dialog-footer">
            <el-button @click="close">
                取消
            </el-button>
            <el-button type="primary" :loading="state.confirmSubmit" :disabled="state.confirmSubmit" @click="onSubmit">
                确定
            </el-button>
        </div>
    </el-dialog>
</template>

<script>
import form from '@/components/diboot/mixins/form'

export default {
  name: 'EmployeeForm',
  mixins: [form],
  data() {
    return {
      baseApi: '/employee',
      attachMoreList: [
        {
          type: 'T',
          target: 'iam_org',
          key: 'short_name',
          value: 'id'
        }
      ]
    }
  }
}
</script>
<style lang="scss" scoped>
</style>
