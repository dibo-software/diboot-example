<template>
    <el-dialog
      class="excel-import"
      :visible.sync="visible"
      title="数据上传"
      @closed="close"
    >
        <excel-import
          v-if="visible"
          :example-url="`${baseApi}/downloadExample`"
          :upload-url="`${baseApi}/upload`"
          :preview-url="`${baseApi}/preview`"
          :preview-save-url="`${baseApi}/previewSave`"
          :fields-required="fieldsRequired"
          @finishedUpload="handleFinishedUpload"
        ></excel-import>
        <div slot="footer" class="dialog-footer">
            <el-button @click="close">关闭</el-button>
        </div>
    </el-dialog>
</template>

<script>
import ExcelImport from '@/components/diboot/components/import/ExcelImport'

export default {
  name: 'EmployeeImport',
  data() {
    return {
      baseApi: '/employee/excel',
      visible: false
    }
  },
  methods: {
    open() {
      this.visible = true
    },
    /**
     * 刷新数据
     */
    handleFinishedUpload() {
      this.$emit('complete')
      this.visible = false
    },
    close() {
      this.visible = false
    }
  },
  computed: {
    /**
     * 后端需要的固定参数
     * @returns {{}}
     */
    fieldsRequired: function() {
      return {}
    }
  },
  components: {
    ExcelImport
  }
}
</script>

<style lang="scss" scoped>
</style>
