<template>
    <div class="app-container">
      <div class="table-page-search-wrapper">
      <el-form :inline="true" label-width="100px">
        <el-row :gutter="18">
                <el-col :md="8" :sm="24">
            <el-form-item label="部门" style="width: 100%;">
              <el-select v-model="queryParam.orgId" placeholder="请选择部门" style="width: 100%;">
                <el-option
                  v-if="more.iamOrgKvList" 
                  v-for="(item, index) in more.iamOrgKvList"
                  :key="index"
                  :value="item.v"
                  :label="item.k"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :md="8" :sm="24">
            <el-form-item label="姓名" style="width: 100%;">
              <el-input v-model="queryParam.realname" placeholder="" style="width: 100%;"/>
            </el-form-item>
          </el-col>
          <template v-if="advanced">
          <el-col :md="8" :sm="24">
            <el-form-item label="电话" style="width: 100%;">
              <el-input v-model="queryParam.cellphone" placeholder="" style="width: 100%;"/>
            </el-form-item>
          </el-col>
          <el-col :md="8" :sm="24">
            <el-form-item label="生日" style="width: 100%;">
              <el-date-picker
                v-model="dateRangeQuery.birthdate"
                value-format="yyyy-MM-dd"
                type="daterange"
                style="width: 100%;">
              </el-date-picker>
          </el-form-item>
        </el-col>
          </template>
          <el-col :md="!advanced && 8 || 24" :sm="24">
            <span class="table-page-search-submitButtons" :style="advanced && { float: 'right', overflow: 'hidden' } || {} ">
              <el-button v-waves type="primary" icon="el-icon-search" @click="onSearch">
                查询
              </el-button>
              <el-button  style="margin-left: 8px" type="info" icon="el-icon-refresh" @click="reset">
               重置
              </el-button>
              <el-link type="primary" :underline="false" @click="toggleAdvanced" style="margin-left: 8px">
                {{ advanced ? '收起' : '展开' }}
                <i :class="advanced ? 'el-icon-arrow-up' : 'el-icon-arrow-down'"/>
              </el-link>
            </span>
          </el-col>
        </el-row>
      </el-form>
    </div>


    <div class="table-operator">
      <el-button v-permission="['create']" style="margin-left: 10px;" type="primary" icon="el-icon-plus" @click="$refs.form.open(undefined)">
        新建
      </el-button>
      <el-button v-permission="['import']" style="margin-left: 10px;" icon="el-icon-upload2" @click="$refs.import.open()">
        导入
      </el-button>
      <el-button v-permission="['export']" style="margin-left: 10px;" :icon="exportLoadingData ? 'el-icon-loading' : 'el-icon-download'" @click="exportData">
        导出
      </el-button>
    </div>

<el-table
      v-loading="loadingData"
      :data="list"
      element-loading-text="Loading"
      fit
      @sort-change="appendSorterParam"
            highlight-current-row
      row-key="id"
    >
      <el-table-column  align="center" label="部门">
      	<template slot-scope="scope">
          <span>{{ scope.row.iamOrgShortName }}</span>
        </template>
      </el-table-column>
      <el-table-column  align="center" label="姓名">
      	<template slot-scope="scope">
          <span>{{ scope.row.realname }}</span>
        </template>
      </el-table-column>
      <el-table-column  align="center" label="身份证号">
      	<template slot-scope="scope">
          <span>{{ scope.row.idcard }}</span>
        </template>
      </el-table-column>
      <el-table-column  align="center" label="生日">
      	<template slot-scope="scope">
          <span>{{ scope.row.birthdate }}</span>
        </template>
      </el-table-column>
      <el-table-column  align="center" label="电话">
      	<template slot-scope="scope">
          <span>{{ scope.row.cellphone }}</span>
        </template>
      </el-table-column>
      <el-table-column  align="center" label="邮箱">
      	<template slot-scope="scope">
          <span>{{ scope.row.email }}</span>
        </template>
      </el-table-column>
      <el-table-column  align="center" label="创建时间">
      	<template slot-scope="scope">
          <span>{{ scope.row.createTime }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作" align="center" width="230" class-name="small-padding fixed-width">
      	<template slot-scope="{row}">
        	<el-button
            v-permission="['detail']"
            type="text"
            @click="$refs.detail.open(row.id)"
          >
            详情
          </el-button>
        	<span
            v-permission="['detail']"
            v-permission-again="['update', 'delete']"
          >
            <el-divider
              direction="vertical"
            />
          </span>
        	<el-dropdown
            v-permission="['update', 'delete']"
            @command="command => menuCommand(command, row)"
          >
          	<el-button type="text">
              更多<i class="el-icon-arrow-down el-icon--right" />
            </el-button>
            <el-dropdown-menu slot="dropdown">
							<el-dropdown-item
                v-permission="['update']"
                command="update"
                icon="el-icon-edit"
              >
                编辑
              </el-dropdown-item>
							<el-dropdown-item
                v-permission="['delete']"
                command="delete"
                icon="el-icon-delete"
              >
                删除
              </el-dropdown-item>
            </el-dropdown-menu>
        </el-dropdown>
				</template>
      </el-table-column>
    </el-table>
    <pagination
        v-show="pagination.total>0"
        :total="pagination.total"
        :page.sync="pagination.current"
        :limit.sync="pagination.pageSize"
        :style="{textAlign: 'right'}"
        @pagination="handlePaginationChanged"
      />
      <diboot-form ref="form" @complete="getList"></diboot-form>
      <diboot-detail ref="detail"></diboot-detail>
      <diboot-import ref="import" @complete="getList"></diboot-import>
    </div>
</template>

<script>
import list from '@/components/diboot/mixins/list'
import waves from '@/directive/waves'
import dibootForm from './form'
import dibootDetail from './detail'
import dibootImport from './excelImport'

export default {
  name: 'EmployeeList',
  directives: { waves },
  components: {
    dibootForm,
    dibootDetail,
    dibootImport
  },
  mixins: [list],
  data() {
    return {
      baseApi: '/employee',
      getListFromMixin: true,
           attachMoreList: [
        {
          type: 'T',
          target: 'iam_org',
          key: 'short_name',
          value: 'id'
        }
      ]
    }
  }
}
</script>
<style lang="scss" scoped>
</style>
