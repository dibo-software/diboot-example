<template>
  <div class="app-container">


<el-form ref="dataForm" :model="form" label-position="right" label-width="100px">
  <el-row :gutter="18">
    <el-col :span="12">
      <el-form-item
        label="员工"
      >
        <el-select
        	filterable
          placeholder="请选择员工"
          v-model="form.employeeId"
          style="width: 100%;"
        >
          <el-option
            value=""
            label="-- 请选择 --"
          />
          <el-option
            v-if="more.employeeKvList"
            v-for="(item, index) in more.employeeKvList"
            :key="index"
            :value="`${item.v}`"
            :label="item.k"
          >
          </el-option>
        </el-select>
      </el-form-item>
    </el-col>
    <el-col :span="12">
      <el-form-item
        label="单位"
      >
        <el-input
          placeholder="请输入单位"
          v-model="form.corpName"
        />
      </el-form-item>
    </el-col>
    <el-col :span="12">
      <el-form-item
        label="电话"
      >
        <el-input
          placeholder="请输入电话"
          v-model="form.corpPhone"
        />
      </el-form-item>
    </el-col>
    <el-col :span="12">
      <el-form-item
        label="起始日期"
      >
        <el-date-picker
          v-model="form.beginDate"
          type="date"
          style="width: 100%;"
        />
      </el-form-item>
    </el-col>
    <el-col :span="12">
      <el-form-item
        label="截止日期"
      >
        <el-date-picker
          v-model="form.endDate"
          type="date"
          style="width: 100%;"
        />
      </el-form-item>
    </el-col>
    <el-col :span="12">
      <el-form-item
        label="联系人"
      >
        <el-input
          placeholder="请输入联系人"
          v-model="form.contactPerson"
        />
      </el-form-item>
    </el-col>
    <el-col :span="12">
      <el-form-item
        label="联系人邮箱"
      >
        <el-input
          placeholder="请输入联系人邮箱"
          v-model="form.contactEmail"
        />
      </el-form-item>
    </el-col>
    <el-col :span="12">
      <el-form-item
        label="所属职级"
      >
        <el-select
        	filterable
          placeholder="请选择所属职级"
          v-model="form.expStatus"
          style="width: 100%;"
        >
          <el-option
            value=""
            label="-- 请选择 --"
          />
          <el-option
            v-if="more.positionGradeKvList"
            v-for="(item, index) in more.positionGradeKvList"
            :key="index"
            :value="item.v"
            :label="item.k"
          >
          </el-option>
        </el-select>
      </el-form-item>
    </el-col>
  </el-row>
</el-form>
    </a-form>
  </div>
</template>

<script>
import form from '@/components/diboot/mixins/form'
import { dibootApi } from '@/utils/request'

export default {
  name: 'addExperience',
  mixins: [form],
  data () {
    return {
      attachMoreList: [
        {
          type: 'T',
          target: 'employee',
          key: 'realname',
          value: 'id'
        },
        {
          type: 'D',
          target: 'POSITION_GRADE'
        }
      ]
    }
  },
  methods: {
    
    open () {
  this.attachMore()
},
    async submit () {
  this.state.confirmSubmit = true
  const values = await this.validate()
  this.enhance(values)
  try {
    const res = await dibootApi.post(`${this.baseApi}/`, values)
    if (res.code === 0) {
      this.submitSuccess(res)
    } else {
      this.submitFailed(res)
    }
  } catch (e) {
    // 执行一系列后续操作
    this.submitFailed(e)
  }
},
    submitSuccess (result) {
  this.$notification.success({
    message: '操作成功',
    description: result.msg
  })
  this.close()
  this.form.resetFields()
  this.$emit('complete')
}
  }

}
</script>
<style lang="less" scoped>
</style>