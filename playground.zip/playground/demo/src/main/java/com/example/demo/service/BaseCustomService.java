package com.example.demo.service;

import com.diboot.core.service.BaseService;

/**
* 自定义BaseService接口
* @author MyName
* @version 1.0
* @date 2020-07-08
 * Copyright © MyCompany
*/
public interface BaseCustomService<T> extends BaseService<T> {

}