package com.example.demo.config;

/**
 * MybatisPlus 相关配置
 * @author www.dibo.ltd
 * @version v1.0
 * @date 2020/10/23
 */
public class MybatisPlusConfig {

}
