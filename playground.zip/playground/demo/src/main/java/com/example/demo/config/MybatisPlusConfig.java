package com.example.demo.config;

import com.diboot.iam.util.IamSecurityUtils;

/**
 * MybatisPlus 相关配置
 * @author www.dibo.ltd
 * @version v1.0
 * @date 2020/10/23
 */
public class MybatisPlusConfig {

    public static void main(String[] args) {
        String password = "pass1234";
        String salt = "406fd5b0";
        String dbPassword = "f071e6bb4b7055ed0cb783f70d0056bd";
        String encryptedPwd = IamSecurityUtils.encryptPwd(password, salt);
        System.out.println(dbPassword);
        System.out.println(encryptedPwd);
        System.out.println(dbPassword.equals(encryptedPwd));
    }

}
